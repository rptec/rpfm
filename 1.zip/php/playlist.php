<?php
#网易云音乐 - MinonHeart
#http://music.163.com/#/user/home?id=16393337
#以下均为示例ID，请填写自己喜欢歌单的ID或者单曲的ID
#特别说明：如果歌单数量过多，会导致切歌的耗时较长，因此，建议只填入一个歌单ID（特意创建一个歌单给这个电台使用就好了）。

#歌单ID
$playlist_list = array(

"33137512", //rp电台

);

#单曲ID
$player_list = array(

"19292800", //Red - Taylor Swift

);
